import pandas as pd
import numpy as np
import build_portfolio
import matplotlib.pyplot as plt


def get_returns():
    return pd.read_pickle('returns.pkl')


def get_risk_adj_signals():
    return pd.read_pickle('signal_risk_adj.pkl')


def get_signal_raw():
    return pd.read_pickle('signal_raw.pkl')


def get_t_cost():
    return pd.read_pickle('t_cost.pkl')


def get_holding_period():
    return pd.read_pickle('holding_period.pkl')


def subs(weights, pred, eta, minY, maxY):
    gmin = -1 / eta * np.log(np.dot(weights, np.exp(pred - (pred - minY) ** 2)))
    gmax = -1 / eta * np.log(np.dot(weights, np.exp(pred - (pred - maxY) ** 2)))
    g = 0.5 * (minY + maxY) - (gmin - gmax) / (2 * (maxY - minY))
    return g


def SEAA(experts, actual, alpha, eta, minY, maxY):
    n = np.size(experts, axis=1)
    t = np.size(experts, axis=0)
    predictions = np.zeros(t)
    w = np.ones(n)
    temp = np.zeros((t, n))
    for i in range(0, t):
        w = w / w.sum()
        w = (1 - alpha) * w + alpha / (n - 1) * (1 - w)
        temp[i,] = w
        predictions[i] = subs(w, experts[i,], eta, minY, maxY)
        w = w * np.exp(-eta * (experts[i,] - actual[i]) ** 2)
        w = (1-alpha)**((experts[i,]-actual[i])**2) 
    return temp


def get_weights(nat_rtn_mdf, signal_mdf):
    ac_nat_rtn_mdf = nat_rtn_mdf.copy()

    ac_signal_mdf = signal_mdf.copy().shift(1)

    asset_ls = ac_nat_rtn_mdf.columns.get_level_values(0).unique().tolist()
    weight_dd = dict()
    for asset in asset_ls:
        asset_rtn_s = ac_nat_rtn_mdf[asset].loc['2010':].dropna()

        asset_sig_df = ac_signal_mdf[asset].loc['2010':].dropna()
        c_idx = sorted(list(set(asset_rtn_s.index).intersection(set(asset_sig_df.index))))
        asset_rtn_s = asset_rtn_s.reindex(c_idx)
        asset_sig_df = asset_sig_df.reindex(c_idx)

        asset_rtn_val = asset_rtn_s.values
        asset_sig_vals = asset_sig_df.values

        w_vals = SEAA(asset_sig_vals,
                     asset_rtn_val,
                     0.2,
                     2,
                     -1,
                     1)

        cols = asset_sig_df.columns
        idx = asset_sig_df.index
        w_df = pd.DataFrame(w_vals, columns=cols, index=idx)
        weight_dd[asset] = w_df

    weights_df = pd.concat(weight_dd, axis=1)

    swap_weight_df = weights_df.swaplevel(axis=1)

    columns_ls = swap_weight_df.columns.get_level_values(0).unique().tolist()
    final_weights_df = pd.DataFrame(columns=columns_ls, index=swap_weight_df.index)
    for col in columns_ls:
        weight_df = swap_weight_df[col].copy()
        missing_ls = list(set(asset_ls).difference(weight_df.columns))
        for missing in missing_ls:
            weight_df.loc[:, missing] = 0

        weight_df = weight_df.div(weight_df.sum(axis=1), axis='index')
        final_weights_df.loc[:, col] = weight_df.max(axis=1)

    weights_df = final_weights_df.copy()
    return weights_df

def get_weighted_signal(asset_class):
    nat_vol_rtn_mdf = get_returns()
    signal_mdf = get_risk_adj_signals()
    weights_df = get_weights(nat_vol_rtn_mdf[asset_class], signal_mdf[asset_class])
    weights_df = weights_df[signal_mdf[asset_class].columns].copy()
    w_signal_df = signal_mdf.mul(weights_df, axis=1, level=1).sum(axis=1, level=0)
    return w_signal_df


def smooth_holding_period(signal_df, hp_days_s):
    if isinstance(signal_df, pd.Series):
        signal_df = pd.DataFrame(signal_df)
    smooth_signal_df = pd.DataFrame()
    for name, signal_s in signal_df.items():
        smooth_signal_s = signal_s.rolling(hp_days_s[name], min_periods=1).mean()
        smooth_signal_df = pd.concat([smooth_signal_df, smooth_signal_s], axis=1, sort=True)
    return smooth_signal_df


def portfolio(asset_class):
    nat_vol_rtn_mdf = get_returns()[asset_class]
    signal_mdf = get_risk_adj_signals()[asset_class]

    tcost_s = get_t_cost()[asset_class]
    hold_s = get_holding_period()[asset_class]

    weights_df = get_weights(nat_vol_rtn_mdf, signal_mdf)
    #weights_df = weights_df.shift(1)  ## as discussed

    #w_signal_df = signal_mdf.mul(weights_df, axis=1, level=1).groupby(level=0, axis=1).sum()
    # Transpose the DataFrame, group by rows (level=0), and sum, then transpose back
    w_signal_df = (signal_mdf.mul(weights_df, axis=1, level=1).T.groupby(level=0).sum().T)


    s_weight_df = smooth_holding_period(w_signal_df, hold_s.loc)

    portfolio_param_dd = {'var_tgt_daily_pct': 0.01, 'risk_parity': False,
                          'sticky_scalar': False, 'long_corr': False,
                          'max_leverage': None, 'max_gross_exp': None, 'holiday_dd': None,
                          'window': 250, 'min_window': 125, 'return_lag': 1}

    port_dd = build_portfolio.calculate(weights_df=s_weight_df,
                                        natural_ret_df=nat_vol_rtn_mdf,
                                        t_cost_s=tcost_s,
                                        **portfolio_param_dd)

    return port_dd

# rates, fx and equity
# Prompt the user for input
ac = input("Enter 'fx', 'rates', or 'equity' for results: ").strip().lower()

# Validate the input
if ac in ['fx', 'rates', 'equity']:
    print(f"You selected: {ac}")
else:
    print("Invalid input. Please enter 'fx', 'rates', or 'equity'.")
# ac = input("Enter 'fx','rates' or 'equity' for results:")
#.strip().upper()'fx'
t_port_ret_df = portfolio(ac)['t_port_ret']
port_ret_df =  portfolio(ac)['port_ret']

t_port_ret_s1 = t_port_ret_df.sum(axis=1)
port_ret_s1 = port_ret_df.sum(axis=1)

f1 = t_port_ret_s1.cumsum()
# f2.to_csv("rates_total_return.csv")
#plt.plot(f1)
# WEALTH OVER TIME
#f2 = (1+t_port_ret_s1).cumprod()
# f1.to_csv("fx_total_wealth.csv")
#plt.plot(f2)

print(np.sqrt(250) * t_port_ret_s1.mean() / t_port_ret_s1.std())
########################################
# plt.plot(f1)
# plt.show()
# plt.plot(f2)
# plt.show()
